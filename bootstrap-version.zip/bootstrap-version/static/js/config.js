// API key
const API_KEY = "pk.eyJ1Ijoic3BlZWRvZnNvdW5kIiwiYSI6ImNrcjJxY2RkZTJlbXQycG1mdmoxMmE3OHcifQ.8NLMfjc4CP3uC8Aq6ap_0Q";
